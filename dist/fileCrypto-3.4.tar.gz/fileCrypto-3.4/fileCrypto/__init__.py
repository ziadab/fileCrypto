from .fileOnAES import *
from .fileOnXOR import *
from .fileOnBase64 import *
from .fileOnBase32 import *
from .fileOnBase16 import *
from .fileOnBlowfish import *
from .fileOnDES import *
from .fileOnDES3 import *
from .fileOnARC2 import *
from .fileOnARC4 import *

__all__ = ['fileOnAES','fileOnXOR','fileOnBase64','fileOnBase32','fileOnBase16','fileOnBlowfish','fileOnARC4','fileOnARC2','fileOnDES3','fileOnDES']

name = "fileCrypto"