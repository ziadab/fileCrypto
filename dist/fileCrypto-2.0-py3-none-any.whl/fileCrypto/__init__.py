from .fileOnAES import *
from .fileOnXOR import *
from .fileOnBase64 import *
from .fileOnBase32 import *
from .fileOnBase16 import *
from .fileOnBlowfish import *
from .fileOnDES import *
from .fileOnDES3 import *

__all__ = ['fileOnAES','fileOnXOR','fileOnBase64','fileOnBase32','fileOnBase16','fileOnBlowfish']

name = "fileCrypto"